# Sample Dataset for Testing Password Detection

This sample dataset demonstrates Nightfall's ability to detect in conversational text. The data has been fully de-identified and can be used to test PHI detection on any data loss prevention (DLP) platform.
